const sql = require(`mssql`) //ייבוא המודול

const db = {
    config: {
        user: 'DB_A4B73A_shenkar_admin',
        password: '!@sh98746987@!',
        server: 'sql6009.site4now.net',
        database: 'DB_A4B73A_shenkar',
        options: {
            enableArithAbort: true
        }
    },

    execSQL: (queryText, res) => {
        //מנסה להתחבר למסד הנתונים
        sql.connect(db.config, (err) => {

            if (err) res.send(err) //קיבלתי שגיאה ואני מחזיר אותה

            // תיצור אובייקט שאחראי על בקשת נתונים
            let request = new sql.Request()

            // select כתוב את משפט ה
            request.query(queryText, (err, result) => {

                if (err) res.send(err)

                // send records as a response
                //console.log(result)
                sql.close()
                res.send(result.recordset)

            })
        })
    }
}


module.exports = db