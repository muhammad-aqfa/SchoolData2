//ייבוא המודול
const express = require(`express`) 
const DB = require(`../db`) 

//יצירת המודול ראוטר
const router = express.Router()

//כל הבקשות שקשורות למסד הנתונים ולמשתמשים
//יצירת משתמש חדש, קבלת פרטים על משתמש וכו

router.get(`/`, (req, res) => {
    let queryText = `select * from users`
    DB.execSQL(queryText, res)
})

router.get(`/:id`, (req, res) => {
    let queryText = `select * from users where id = ${req.params.id}`
    DB.execSQL(queryText, res)
})


module.exports = router