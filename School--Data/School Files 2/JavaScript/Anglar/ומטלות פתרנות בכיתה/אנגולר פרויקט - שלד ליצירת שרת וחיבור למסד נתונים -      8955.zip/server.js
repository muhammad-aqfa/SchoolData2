const express = require(`express`) //ייבוא של המודול
const DB = require(`./db`) //ייבוא מודול שיצרתי
const PORT = process.env.PORT || 5100

const app = express() //הפעלת המודול
app.use(express.static(`public`)) //--> __dirname

//ייבוא של כל הראוטרים
const usersRouter = require(`./route/users`) //ייבוא מודול המשתמשים

app.get(`/`, (req, res) => {
    res.sendFile(path.join(__dirname, `/index.html`))
})

//מימוש בניתוב המתאים
app.use(`/users`, usersRouter)




//הפעלה של השרת
app.listen(PORT, () => {
    console.log(`app started: http://localhost:${PORT}`)
})



