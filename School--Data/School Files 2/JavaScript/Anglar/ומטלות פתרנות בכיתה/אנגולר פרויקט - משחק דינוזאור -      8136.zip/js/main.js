import Dino from "./dino.js";
import Box from "./box.js";

const box = new Box(window.innerHeight - 200, window.innerWidth - 300)
const dino = new Dino(window.innerHeight - 250, 50) //create the dino object
const MOVE = 20 //each step is 20px

box.move()

//event for moving the player on eache key press
document.addEventListener(`keypress`, (event) => {
    switch (event.key) {
        case `d`:
            dino.moveRight(MOVE)
            break;
        case `a`:
            dino.moveLeft(MOVE)
            break;
        case `s`:
            dino.moveDown(MOVE)
            break;
        case `w`:
            dino.moveUp(MOVE)
            break;
        case ` `:
            dino.jump(300, 150)
            break
        default:
            break;
    }
})







