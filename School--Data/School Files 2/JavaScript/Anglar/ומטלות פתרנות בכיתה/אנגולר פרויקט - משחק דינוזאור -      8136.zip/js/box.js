import Dino from "./dino.js";

export default class Box {
    element;
    top;
    left;

    //constructor
    constructor(top, left) {
        this.element = document.querySelector(`#box`)
        this.top = top
        this.left = left
        this.setPosition()
    }

    //methods
    setPosition() {
        this.element.style.top = `${this.top}px`
        this.element.style.left = `${this.left}px`
        this.element.style.display = `block`
    }

    move() {
        //document.querySelector(`#dinoPlayer`).style.left -->  left לוקח את הערך של ה  
        //document.querySelector(`#dinoPlayer`).style.top -->  top לוקח את הערך של ה  
        //split(`px`) --> px הופך למערך כאשר המפריד בין כל תא הוא 
        let interval = setInterval(() => {
            let dinoRight = parseInt(document.querySelector(`#dinoPlayer`).style.left.split(`px`)[0])
            dinoRight += 160

            let dinoBottom = parseInt(document.querySelector(`#dinoPlayer`).style.top.split(`px`)[0])
            dinoBottom -= 76;

            if (this.left - 10 < dinoRight && this.top + 10 > dinoBottom) { //נקודת התנגשות
                clearInterval(interval)
            }
            else {
                this.left -= 36
                this.setPosition()
                //console.table(dinoRight, this.left)
                console.table(dinoBottom, this.top)
            }
        }, 500)
    }
}