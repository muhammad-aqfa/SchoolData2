
export default class Dino {
    //properties
    element;
    top;
    left;

    //constructor
    constructor(top, left) {
        this.element = document.querySelector(`#dinoPlayer`)
        this.top = top
        this.left = left
        this.setPosition()
    }

    //methods
    setPosition() {
        this.element.style.top = `${this.top}px`
        this.element.style.left = `${this.left}px`
    }

    moveRight(value) {
        if (this.left + value < window.innerWidth - 160) { //-160 מפני שנרצה להתייחס לפינה הימנית העליונה
            this.left += value
            this.setPosition()
        }
    }

    moveLeft(value) {
        if (this.left - value > 0) {
            this.left -= value
            this.setPosition()
        }
    }

    moveUp(value) {
        if (this.top - value >= 670) { //גבול עליון - לא עובר את הכביש
            this.top -= value
            this.setPosition()
        }

    }

    moveDown(value) {
        if (this.top + value <= 750) { //גבול תחתון - לא עובר את הכביש
            this.top += value
            this.setPosition()
        }
    }

    jump(top, left) {
        if (this.left + left < window.innerWidth - 160) {
            this.top -= top
            this.left += left
            this.setPosition()
            setTimeout(() => {
                this.top += top
                this.left += left
                this.setPosition()
            }, 370)
        }

    }


}