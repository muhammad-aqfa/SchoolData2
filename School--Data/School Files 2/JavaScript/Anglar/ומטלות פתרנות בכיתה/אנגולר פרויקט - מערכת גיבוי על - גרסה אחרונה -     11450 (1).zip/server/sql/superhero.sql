
/*

.MDF -->  Main Data File --> קובת המידע של מסד הנתונים 

.LDF --> Log Data File --> קובץ הלוג של מסד הנתונים

*/


create table Superhero(
	id int identity(1,1) primary key,
	first_name nvarchar(150) not null,
	last_name nvarchar(150) not null,
	superhero_name nvarchar(150) not null,
	skills ntext, 
	img ntext
)
go

--פרוצדורה להוסת גיבור על
create proc AddSuperhero
	@first_name nvarchar(150),
	@last_name nvarchar(150),
	@superhero_name nvarchar(150),
	@skills ntext, 
	@img ntext
as
	begin tran
		--הפעלת טרנזקציה
		insert into [dbo].[Superhero]([first_name], [last_name], [superhero_name], [skills], [img])
			values(@first_name, @last_name, @superhero_name, @skills, @img)
	if (@@ERROR <> 0) --אם ארעה שגיאה
		begin --{
			rollback tran --תבטל את הפעולה
			return --תחזור חזרה
		end --}
	else
		commit tran -- תבצע את הפעולה בקובץ הראשי
go

--פרוצדורה למחיקת גיבור על
create proc DeleteSuperhero
	@id int
as
	begin tran
		delete from [dbo].[Superhero] where [id] = @id
	if (@@ERROR <> 0)
		begin
			rollback tran
			return
		end
	else
		commit tran
go

--פרוצדורה לעדכון פרטים של גיבור העל
create proc EditSuperhero
	@id int,
	@first_name nvarchar(150),
	@last_name nvarchar(150),
	@superhero_name nvarchar(150),
	@skills ntext, 
	@img ntext
as
	begin tran
		update [dbo].[Superhero]
			set [first_name] = @first_name,
				[last_name] = @last_name,
				[superhero_name] = @superhero_name,
				[skills] = @skills,
				[img] = @img
			where [id] = @id
	if (@@ERROR <> 0) 
		begin --{
			rollback tran 
			return 
		end --}
	else
		commit tran 
go






