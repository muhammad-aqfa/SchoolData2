const sql = require(`mssql`) //ייבוא המודול

const db = {
    config: {
        user: 'DB_A4B73A_shenkar_admin',
        password: '!@sh98746987@!',
        server: 'sql6009.site4now.net',
        database: 'DB_A4B73A_shenkar',
        options: {
            enableArithAbort: true
        }
    },
    //select פקודה להרצת פונקציה או משפט 
    select: (queryText, res) => {
        try {
            //מנסה להתחבר למסד הנתונים
            sql.connect(db.config, (err) => {

                if (err) res.send(err) //קיבלתי שגיאה ואני מחזיר אותה

                // תיצור אובייקט שאחראי על בקשת נתונים
                let request = new sql.Request()

                // select כתוב את משפט ה
                request.query(queryText, (err, result) => {

                    if (err) res.send(err)

                    // send records as a response
                    //console.log(result)
                    sql.close()
                    res.send(result.recordset) //rowsAffected
                })
            })
        } catch (error) {
            res.send(error)
        }
    },
    //פקודה להרצת פרוצדורה
    exec: (queryText, res) => {
        try {
            //מנסה להתחבר למסד הנתונים
            sql.connect(db.config, (err) => {

                if (err) res.send(err) //קיבלתי שגיאה ואני מחזיר אותה

                // תיצור אובייקט שאחראי על בקשת נתונים
                let request = new sql.Request()

                // select כתוב את משפט ה
                request.query(queryText, (err, result) => {

                    if (err) res.send(err)

                    // send records as a response
                    //console.log(result)
                    sql.close()
                    res.send({ rowsAffected: result.rowsAffected[0] })

                })
            })
        } catch (error) {
            res.send(error)
        }
    }
}


module.exports = db