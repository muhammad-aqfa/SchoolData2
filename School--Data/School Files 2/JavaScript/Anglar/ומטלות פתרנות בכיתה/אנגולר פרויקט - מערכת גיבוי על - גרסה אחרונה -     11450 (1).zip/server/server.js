const express = require(`express`) //ייבוא של המודול
const cors = require('cors')
const PORT = process.env.PORT || 5100

const app = express() //הפעלת המודול
app.use(cors())
app.use(express.json()) //אפשרות לקבל נתונים מאובייקט JSON
//app.use(express.static(`public`)) //--> __dirname

app.use(`/api/heroes`, require(`./route/heroesAPI`))

//הפעלה של השרת
app.listen(PORT, () => {
    console.log(`app started: http://localhost:${PORT}`)
})