//ייבוא המודול
const express = require(`express`)
const DB = require(`../modules/db`)

//יצירת המודול ראוטר
const heroesAPI = express.Router()

//הכתובת הראשית - מופעל אוטומטית
heroesAPI.get(`/`,(req, res) => {
    let sql = `select * from Superhero`
    DB.select(sql, res)
})

heroesAPI.get(`/:id`, (req, res) => {
    let sql = `select * from Superhero where id=${req.params.id}`
    DB.select(sql, res)
})

heroesAPI.post(`/add`, (req, res) => {
    let sql = `exec AddSuperhero N'${req.body.first_name}', N'${req.body.last_name}', N'${req.body.superhero_name}', N'${req.body.skills}', N'${req.body.img}'`
    DB.exec(sql, res)
})

heroesAPI.post(`/edit`, (req, res) => {
    let sql = `exec EditSuperhero ${req.body.id}, N'${req.body.first_name}', N'${req.body.last_name}', N'${req.body.superhero_name}', N'${req.body.skills}', N'${req.body.img}'`
    DB.exec(sql, res)
})

heroesAPI.post(`/delete`, (req, res) => {
    let sql = `exec DeleteSuperhero ${req.body.id}`
    DB.exec(sql, res)
})



//ייצוא
module.exports = heroesAPI