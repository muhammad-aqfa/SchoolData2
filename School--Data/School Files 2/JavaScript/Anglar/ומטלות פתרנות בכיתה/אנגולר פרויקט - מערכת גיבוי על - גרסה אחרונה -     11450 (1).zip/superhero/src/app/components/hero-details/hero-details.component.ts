import { Component, OnInit, Input } from '@angular/core';
import { HeroService, Hero } from 'src/app/services/hero/hero.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hero-details',
  templateUrl: './hero-details.component.html',
  styleUrls: ['./hero-details.component.scss']
})
export class HeroDetailsComponent implements OnInit {

  @Input() hero: Hero //פרמטר שהקומפוננטה מקבלת

  constructor(private heroService: HeroService, private router: Router) { }

  ngOnInit(): void {
  }

  public showHeroPage(hero): void {
    this.router.navigate([`/hero/${hero.id}`])
  }

  public deleteHero(id: number): void {
    this.heroService.deleteHero(id).subscribe(
      (success) => {
        //אם נמחק בהצלחה ממסד הנתונים
        if (success.rowsAffected > 0) {
          //אז תמחק מהנתונים באנגולר
          // for (let i = 0; i < this.heroesList.length; i++) {
          //   if (this.heroesList[i].id === id) {
          //     this.heroesList.splice(i, 1);
          //     break;
          //   }
          // }
        }
      },
      (error) => { console.log(error) }
    )
  }

}
