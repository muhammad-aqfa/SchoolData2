import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Hero, HeroService } from 'src/app/services/hero/hero.service';

@Component({
  selector: 'app-add-hero',
  templateUrl: './add-hero.component.html',
  styleUrls: ['./add-hero.component.scss']
})
export class AddHeroComponent implements OnInit {

  hero: Hero = new Hero();
  showError: boolean = false;

  @Output() addedHero = new EventEmitter() //פרמטר שהקומפוננטה מחזירה להורה שלה

  constructor(private heroService: HeroService) { }

  ngOnInit(): void {
  }

  public addHero(event) {
    event.preventDefault()
    if (this.hero.first_name != undefined && this.hero.last_name != undefined && this.hero.skills != undefined && this.hero.superhero_name != undefined)
      this.heroService.addHero(this.hero).subscribe(
        (success) => {
          if (success.rowsAffected > 0) {
            //שליחת אישור להפעיל את הפונקציה הרולננטית בקומפוננטה של ההורה. האישור נשלח עם האובייקט של הגיבור שהתווסף למסד הנתונים
            this.addedHero.emit(this.hero) 
            this.showError = false;
          }

        }, //OK
        (error) => { console.log(error) } //ERROR
      )
    else {
      this.showError = true;
    }
  }

}
