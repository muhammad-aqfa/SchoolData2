import { Component, OnInit } from '@angular/core';
import { HeroService, Hero } from 'src/app/services/hero/hero.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss']
})
export class HeroComponent implements OnInit {

  public hero: Hero = new Hero()
  public id: number

  constructor(private heroService: HeroService, private activatedRoute: ActivatedRoute, private router: Router) {
    //שליפה של הפרמטר מתוך הכתובת
    this.id = parseInt(this.activatedRoute.snapshot.paramMap.get(`id`))

    this.heroService.getHeroById(this.id).subscribe(
      //השרת מחזיר מערך ואני מעוניין לגשת לאובייקט הראשון
      (hero) => { this.hero = hero[0] },
      (error) => { console.log(error) }
    )

  }

  ngOnInit(): void {
  }

  public editHero(event) {
    event.preventDefault()
    this.heroService.editHero(this.hero).subscribe(
      (success) => {
        if (success.rowsAffected > 0) {
          alert(`update successfuly`)
          this.router.navigate(['/'])
        }
      },
      (error) => { console.log(error) }
    )

  }

}
