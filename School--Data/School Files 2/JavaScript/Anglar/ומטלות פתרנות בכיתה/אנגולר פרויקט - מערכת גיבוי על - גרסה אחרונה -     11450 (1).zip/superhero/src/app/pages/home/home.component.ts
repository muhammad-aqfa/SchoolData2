import { Component, OnInit } from '@angular/core';
import { HeroService, Hero } from 'src/app/services/hero/hero.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public heroesList: Array<Hero>;

  //HTML פועל לאחר טעינת הקומפוננטה אבל לפני הצגת 
  constructor(private heroService: HeroService, private router: Router) {

    //subscribe --> ממתין לתשובה מהשרת
    this.heroService.getAll().subscribe(
      (heroes) => { this.heroesList = heroes }, //OK
      (error) => { console.log(error) } //ERROR
    )
  }

  ngOnInit(): void {

  }

  //הפעלת הפונקציה לאחר קבלת אישור מתוך הקומפוננטה של הוספת גיבור
  public updateHeroList(hero: Hero) {
    
    this.heroesList.push(hero) //עדכון של רשימת הגיבורים
  }


}
