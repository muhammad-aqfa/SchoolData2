import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  constructor(private http: HttpClient) { }

  public getAll(): Observable<Hero[]> {
    //return this.http.get<Hero[]>(`http://localhost:5100/api/heroes`, { withCredentials: true }) //לא עובד בזמן פיתוח
    return this.http.get<Hero[]>(`http://localhost:5100/api/heroes`)
  }

  public getHeroById(id): Observable<Hero[]> {
    //return this.http.get<Hero[]>(`http://localhost:5100/api/heroes/${id}`, { withCredentials: true }) //לא עובד בזמן פיתוח
    return this.http.get<Hero[]>(`http://localhost:5100/api/heroes/${id}`)
  }

  public editHero(hero: Hero): Observable<any> {
    //return this.http.post<any>(`http://localhost:5100/api/heroes/edit`, hero, { withCredentials: true }) //לא עובד בזמן פיתוח
    return this.http.post<any>(`http://localhost:5100/api/heroes/edit`, hero)
  }

  public deleteHero(id): Observable<any> {
    //return this.http.post<any>(`http://localhost:5100/api/heroes/delete`, id, { withCredentials: true }) //לא עובד בזמן פיתוח
    return this.http.post<any>(`http://localhost:5100/api/heroes/delete`, {id})
  }

  public addHero(hero: Hero): Observable<any> {
    //return this.http.post<any>(`http://localhost:5100/api/heroes/edit`, hero, { withCredentials: true }) //לא עובד בזמן פיתוח
    return this.http.post<any>(`http://localhost:5100/api/heroes/add`, hero)
  }
}

export class Hero {
  id: number;
  first_name: string;
  last_name: string;
  superhero_name: string;
  skills: string;
  img: string;
}
