export interface Hero {
    id: number,
    first_name: string,
    last_name: string,
    superhero_name: string,
    skills: string,
    img: string
}