import { Component, OnInit } from '@angular/core';
import { HeroService } from 'src/app/services/hero/hero.service';
import { Hero } from 'src/app/services/hero/hero.interface';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public heroesList: Array<Hero>;

  //HTML פועל לאחר טעינת הקומפוננטה אבל לפני הצגת 
  constructor(private heroService: HeroService, private router: Router) {

    //subscribe --> ממתין לתשובה מהשרת
    this.heroService.getAll().subscribe(
      (heroes) => { this.heroesList = heroes }, //OK
      (error) => { console.log(error) } //ERROR
    )
  }

  ngOnInit(): void {

  }

  public showHeroPage(hero): void {
    this.router.navigate([`/hero/${hero.id}`])
  }

  public deleteHero(id: number): void {
    this.heroService.deleteHero(id).subscribe(
      (success) => {
        //אם נמחק בהצלחה ממסד הנתונים
        if (success.rowsAffected > 0) {
          //אז תמחק מהנתונים באנגולר
          for (let i = 0; i < this.heroesList.length; i++) {
            if (this.heroesList[i].id === id) {
              this.heroesList.splice(i, 1);
              break;
            }
          }
        }
      },
      (error) => { console.log(error) }
    )

  }

}
