export interface College {
    id: number,
    name: string,
    numOfStudents: number
}