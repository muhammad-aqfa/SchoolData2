import { Component, OnInit } from '@angular/core';
import { College } from '../../services/college/college';
import { CollegeService } from '../../services/college/college.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-college',
  templateUrl: './delete-college.component.html',
  styleUrls: ['./delete-college.component.scss']
})
export class DeleteCollegeComponent implements OnInit {

  colleges: Array<College> = []
  selectedCollege: College = { id: 0, name: '', numOfStudents: 0 }

  constructor(private collegeService: CollegeService, private router: Router) {
    this.colleges = this.collegeService.getAllColleges()
    this.selectedCollege = this.colleges[0]
  }

  ngOnInit(): void {
  }

  setCurrentCollege(event) {
    let name = event.target.value
    this.selectedCollege = this.colleges.find((college) => {
      return college.name === name
    })
  }

  delete() {
    this.collegeService.deleteCollege(this.selectedCollege)
    alert(`deleted`)
    this.router.navigate([`/`])
  }

}
