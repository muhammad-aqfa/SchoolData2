import { CollegeService } from './../../services/college/college.service';
import { Component, OnInit } from '@angular/core';
import { College } from 'src/app/services/college/college';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-college',
  templateUrl: './add-college.component.html',
  styleUrls: ['./add-college.component.scss']
})
export class AddCollegeComponent implements OnInit {

  college: College = { id: 0, name: '', numOfStudents: 0 }

  constructor(private collegeService: CollegeService, private router: Router) { }

  ngOnInit(): void {
  }

  add() {
    this.collegeService.addNewCollege(this.college)
    alert(`added succesfully`)
    this.router.navigate([`/`])
  }





}
