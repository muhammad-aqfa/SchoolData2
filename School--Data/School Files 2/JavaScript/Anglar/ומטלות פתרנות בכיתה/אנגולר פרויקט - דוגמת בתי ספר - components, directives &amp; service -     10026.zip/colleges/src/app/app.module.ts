import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './pages/root/app.component';
import { AddCollegeComponent } from './pages/add-college/add-college.component';
import { EditCollegeComponent } from './pages/edit-college/edit-college.component';
import { DeleteCollegeComponent } from './pages/delete-college/delete-college.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AllCollegesComponent } from './pages/all-colleges/all-colleges.component';

@NgModule({
  declarations: [
    AppComponent,
    AddCollegeComponent,
    EditCollegeComponent,
    DeleteCollegeComponent,
    NavbarComponent,
    AllCollegesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
