import { CollegeService } from '../../services/college/college.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-colleges',
  templateUrl: './all-colleges.component.html',
  styleUrls: ['./all-colleges.component.scss']
})
export class AllCollegesComponent implements OnInit {

  allColleges;

  constructor(private collegeService: CollegeService) {
    this.allColleges = this.collegeService.getAllColleges()

  }

  ngOnInit(): void {
  }



}
