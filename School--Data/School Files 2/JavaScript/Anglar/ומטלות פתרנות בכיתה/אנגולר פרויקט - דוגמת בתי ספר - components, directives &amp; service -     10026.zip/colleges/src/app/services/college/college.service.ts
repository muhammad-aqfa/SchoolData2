import { Injectable } from '@angular/core';
import { College } from './college'
import { collectExternalReferences } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class CollegeService {

  //DB משתנה שמדמה רשימת נתונים מתוך 
  private AllColleges: Array<College> = [
    { id: 1, name: `College 1`, numOfStudents: 500 },
    { id: 2, name: `College 2`, numOfStudents: 600 },
    { id: 3, name: `College 3`, numOfStudents: 700 },
    { id: 4, name: `College 4`, numOfStudents: 800 },
    { id: 5, name: `College 5`, numOfStudents: 900 }
  ]

  constructor() { }

  getAllColleges(): Array<College> { //College[]
    return this.AllColleges
  }

  addNewCollege(college: College): void {
    this.AllColleges.push(college)
  }

  editCollege(college: College): void {
    this.AllColleges.find((item) => {
      if (item.id === college.id) item.numOfStudents = college.numOfStudents
    })
  }

  deleteCollege(college: College): void {
    for (let i = 0; i < this.AllColleges.length; i++) {
      if (this.AllColleges[i].id === college.id) {
        this.AllColleges.splice(i, 1) //מחיקת איבר מהמערך
        break
      }
    }
  }

}
