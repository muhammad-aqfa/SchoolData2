import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//Pages
import { AllCollegesComponent } from './pages/all-colleges/all-colleges.component';
import { AddCollegeComponent } from './pages/add-college/add-college.component';
import { EditCollegeComponent } from './pages/edit-college/edit-college.component';
import { DeleteCollegeComponent } from './pages/delete-college/delete-college.component';

const routes: Routes = [
  {path:``, component: AllCollegesComponent},
  {path: `add`, component: AddCollegeComponent},
  {path: `edit`, component: EditCollegeComponent},
  {path: `delete`, component: DeleteCollegeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
